window.onload = pageload;

function pageload() {
    var blue = document.getElementById("blue");
    blue.onclick = blueText;
    var green = document.getElementById("green");
    green.onclick = greenText;
    var size = document.getElementById("sizeid");
    size.onclick = changeSize;
    var color = document.getElementById("bgcolor");
    color.onclick = bgColor;
    var us = document.getElementById("us");
    us.onclick = usFlag;
    var eu = document.getElementById("eu");
    eu.onclick = euFlag;
    var m = document.getElementById("m");
    m.onclick = mSize;
    var l = document.getElementById("l");
    l.onclick = lSize;
    var xl = document.getElementById("xl");
    xl.onclick = xlSize;
}

function mSize() {
    p = document.getElementById("myText");
    p.style.fontSize = "12";
}

function lSize() {
    p = document.getElementById("myText");
    p.style.fontSize = "18";
}

function xlSize() {
    p = document.getElementById("myText");
    p.style.fontSize = "24";
}

function blueText() {
    p = document.getElementById("myText");
    p.style.color = "blue";
}

function greenText() {
    p = document.getElementById("myText");
    p.style.color = "green";
}

function changeSize() {
    var size = document.getElementById("sizeid");
    p = document.getElementById("myText");
    p.style.fontSize = size.value + "pt";
}

function usFlag() {
    var size = document.getElementById("sizeid");
    p = document.getElementById("myText");
    p.style.fontSize = size.value + "pt";
}

function bgColor() {
    var color = document.getElementById("bgcolor");
    document.getElementById("div").style.backgroundColor = "#ffffff";
}