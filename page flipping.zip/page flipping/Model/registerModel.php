<?php
$id = 1;

Class registerModel {
	
	public $connection;
	
	var $id;
	// function __construct(){	
// 		
// 		$this->conn = new mysqli("localhost:3306", "root", "", "pageflipping");	
// 		
// 	}
// 	
	function insertRecord($email, $password) {
		require_once('Model/connectModel.php');

		$email = mysqli_real_escape_string($connection, $email);
        $password = mysqli_real_escape_string($connection, $password);
		$sql = "INSERT INTO logininfo (email, password)
        VALUES ('$email', '$password')"; 
		// 
// 		$result = mysqli_query($connection, $sql) ;
			
		if ($this->connection->mysqli_query($sql) === TRUE) {
      
		echo "New User created successfully";
		} else {
		echo "Error: User couldn’t be created. Please try again.";

		}
		$this->conn->close(); // close DB connection		
		
	}


?>