<?php

include "View/homeView.php";

class siteController {

    public $model, $view;
	
	function __construct() {	
	}
	
	function viewMenu(){		
		
		$this->view = new homeView();
	}	
	
	function actions($flag) {	
	
// 	    $this->viewMenu();	
	    	
		if($flag=="register"){
		   include "View/registerMenu.html";
		}  
		
		include "Model/registerModel.php";
		$this->resisterModel = new registerModel();
		
		if($flag=="insertRecord"){		  		
		
			$this->resisterModel->insertRecord($_POST['email'], $_POST['password']);		  
			
		}
		
		if($flag=="login"){		 
			include "View/loginView.html";
		}
		
		include "Model/loginModel.php";
		$this->loginModel = new loginModel();
			
	    if($flag=="authenticateUser"){		  		
		
			$this->loginModel->authenticateUser($_REQUEST['email'], $_REQUEST['password']);
		}
		
		if($flag=="lostpassword") {
			include "View/lostPassword.html";
		}
		
		if($flag=="terms") {
			include "View/Terms-and-Conditions-Template.txt";
		}
	}
}

?>